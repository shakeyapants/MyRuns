MY_STRAVA_CLIENT_ID = 17599
MY_STRAVA_SECRET = '37170e7c68ee72c37c5f6febc40d93d3ad1dc244'
REDIRECT_URI = 'http://192.168.1.178:5000/authorize'
SECRET_KEY = '5G3aLPbm192yxFKgau00fHpecwH2XT'
DATABASE = 'sqlite://///Users/Angelina/PycharmProjects/MyRuns_project/MyRuns/user_token.db'
